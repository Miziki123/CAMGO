// Initialize Leaflet map
var map = L.map('map').setView([4.051, 9.708], 13); // Default center (Douala, Cameroon)

// Add OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

var serviceCenterMarkers = [];
var wifiHotspotMarkers = [];
var selectedServiceCenter = null;

// Function to get user's current location
function getCurrentLocation(callback) {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                callback(latitude, longitude);
            },
            () => {
                alert("Unable to retrieve your location.");
                callback(4.051, 9.708); // Default to Douala
            }
        );
    } else {
        alert("Geolocation is not supported by this browser.");
        callback(4.051, 9.708); // Default to Douala
    }
}

// Function to fetch CAMTEL locations from Overpass API
function fetchCAMTELLocations(lat, lng, callback) {
    const query = `
        [out:json];
        node["amenity"="camtel"](around:5000, ${lat}, ${lng});
        out;
    `;
    
    const apiUrl = `https://overpass-api.de/api/interpreter?data=${encodeURIComponent(query)}`;
    
    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            const locations = data.elements.map(element => ({
                name: element.tags.name || "Unknown",
                lat: element.lat,
                lng: element.lon,
                address: element.tags.address || "No address",
                hours: element.tags.opening_hours || "No hours",
                contact: element.tags.phone || "No contact"
            }));
            callback(locations);
        })
        .catch(error => {
            alert("Failed to fetch CAMTEL locations. Please try again.");
            console.error("Error fetching CAMTEL locations:", error);
        });
}

// Find and display service centers
function findServiceCenters() {
    getCurrentLocation((lat, lng) => {
        fetchCAMTELLocations(lat, lng, (locations) => {
            clearMarkers(serviceCenterMarkers);
            locations.forEach(center => {
                const marker = L.marker([center.lat, center.lng]).addTo(map);
                marker.bindPopup(`<b>${center.name}</b><br>${center.address}<br>${center.hours}<br>${center.contact}`);
                marker.on('click', () => showServiceCenterInfo(center));
                serviceCenterMarkers.push(marker);
            });

            map.setView([lat, lng], 13);
        });
    });
}

// Find and display Wi-Fi hotspots
function findWifiHotspots() {
    getCurrentLocation((lat, lng) => {
        // Example Wi-Fi hotspots data (replace with real API if available)
        const wifiHotspots = [
            { name: "Wi-Fi Plaza", lat: 4.050, lng: 9.708, address: "Wi-Fi Plaza, Douala", hours: "24/7" }
        ];

        clearMarkers(wifiHotspotMarkers);
        wifiHotspots.forEach(hotspot => {
            const marker = L.marker([hotspot.lat, hotspot.lng]).addTo(map);
            marker.bindPopup(`<b>${hotspot.name}</b><br>${hotspot.address}<br>${hotspot.hours}`);
            wifiHotspotMarkers.push(marker);
        });

        map.setView([lat, lng], 13);
    });
}

// Check service availability (mock implementation)
function checkServiceAvailability() {
    alert("Service availability feature is not implemented yet.");
}

// Show service center info in the info card
function showServiceCenterInfo(center) {
    selectedServiceCenter = center;
    const infoCard = document.getElementById('service-center-info');
    const details = document.getElementById('service-center-details');

    details.innerHTML = `
        <h2>${center.name}</h2>
        <p><strong>Address:</strong> ${center.address}</p>
        <p><strong>Hours:</strong> ${center.hours}</p>
        <p><strong>Contact:</strong> ${center.contact}</p>
    `;

    infoCard.classList.remove('hide');
}

// Clear all markers from the map
function clearMarkers(markers) {
    markers.forEach(marker => map.removeLayer(marker));
    markers.length = 0;
}

// Get directions to the selected service center
function getDirections() {
    if (selectedServiceCenter) {
        const url = `https://www.openstreetmap.org/directions?from=Current%20Location&to=${selectedServiceCenter.lat},${selectedServiceCenter.lng}`;
        window.open(url, '_blank');
    } else {
        alert("Please select a service center first.");
    }
}

// Submit a review
function submitReview() {
    const name = document.getElementById('name').value;
    if (name === "") {
        alert("Please enter your name.");
        return;
    }
    alert(`Thank you, ${name}, for your review!`);
}

// Send a comment using EmailJS
function sendComment() {
    const email = document.getElementById('email').value;
    const comment = document.getElementById('comment').value;

    if (email === "" || comment === "") {
        alert("Please fill out both fields.");
        return;
    }

    emailjs.send('service_o8csyd6', 'template_352v5ql', {
        from_email: email,
        message: comment,
    }, 'g35Yr6cMLmWz9jTuL')
    .then(() => {
        alert("Comment sent successfully!");
    })
    .catch(error => {
        alert("Failed to send comment. Please try again.");
        console.error("Error sending comment:", error);
    });
}

// Rating functionality
function setRating(rating) {
    const stars = document.querySelectorAll('.rating span');
    stars.forEach((star, index) => {
        if (index < rating) {
            star.classList.add('selected');
        } else {
            star.classList.remove('selected');
        }
    });
}

// Toggle dark/light mode
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
}

// Initialize EmailJS
emailjs.init('g35Yr6cMLmWz9jTuL');
